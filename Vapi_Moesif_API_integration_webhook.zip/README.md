# Vapi webhook and Moesif API integration

## Install dependencies

```
npm install
```

## Run

```
npm start
```
